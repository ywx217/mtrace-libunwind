#ifndef elf32_h
#define elf32_h

#ifndef ELF_CLASS
#define ELF_CLASS	ELFCLASS32
#endif
#include "elfxx.h"

#endif /* elf32_h */
